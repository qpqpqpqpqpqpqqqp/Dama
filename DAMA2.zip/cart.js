let cart = {
  'qwerty': {
      "name":
      "count":
  },
  'uiop': {
      "name":
      "count":
};

document.onclick = event => {
  if (event.target.classList.contains('plus')) {
    plusFunction(event.target.dataset.id);
  }
  if (event.target.classList.contains('minus')) {
    minusFunction(event.target.dataset.id);
  }

}

const plusFunction = id => {
  cart[id]['count']++;
  renderCart();
}

const minusFunction = id => {
  if (cart[id]['count'] - 1 == 0) {
    renderCart(id);
    return true;
  }
  cart[id]['count']--;
  renderCart();
}

const deleteFunction = id => {
  delete cart[id];
  renderCart();
}

const renderCart = () => {
  console.log(cart);
}

renderCart();
